package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

//@RestController
public class StudentDaoRest
{
@Autowired
 StudentDao dao;

@PostMapping("insert")
public Student insert(@RequestBody Student s)
{
	return dao.insertStident(s);
}

//insert a collection of objects
@PostMapping("insertall")
public List<Student> insertall(@RequestBody List<Student> s)
{
	return dao.insertAll(s);
}

@GetMapping("getall")
public List<Student> getall()
{return dao.getAll();
}

@GetMapping("getbyid/{id}")
public Student getByid(@PathVariable("id") int  id)
{return dao.getbyid(id);
}

@DeleteMapping("deletebyid/{id}")
public String deleteByid(@PathVariable("id") int id)
{return dao.deleteByid(id);}

@PutMapping("update")
public Student update(@RequestBody Student s)
{return dao.update(s);
}
}