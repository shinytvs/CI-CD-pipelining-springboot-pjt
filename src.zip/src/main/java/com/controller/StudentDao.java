package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentDao
{

@Autowired
StudentRepo srepo;
//insert single
public Student insertStident(Student s)
{return srepo.save(s);}


public List<Student> getAll()
{return srepo.findAll();}

public Student getbyemail(String email)
{return srepo.findByEmailAddress(email);}

//fetch by Id
public Student getbyid(int id)
{ return srepo.findById(id).orElse(null);
}


//insert a collection
public  List<Student> insertAll(List<Student> s)
{return srepo.saveAll(s);}

public String deleteByid(int id)
{
srepo.deleteById(id);
return "deleted th eid"+ id;
}
 

//update-find the value n save
public Student update(Student s)
{
	
Student news=srepo.findById(s.getSid()).orElse(null);
news.setName("Pavan");
return srepo.save(news);
	
}
}





