package com.controller;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface StudentRepo extends JpaRepository<Student,Integer>
{
	 @Query("select u from Student u where u.email = ?1")
	  Student findByEmailAddress(String emailid);

}
